<?php
require_once __DIR__ . '/../config/db.php';

$id = (int) ($_GET['id'] ?? 0);
$pdo = db();

$vStmt = $pdo->prepare('SELECT * FROM vehicles WHERE id = ?');
$vStmt->execute([$id]);
$v = $vStmt->fetch();
if (!$v) {
    flash('error', 'Vehicle not found.');
    redirect('index.php');
}

$docs = $pdo->prepare('SELECT * FROM documents WHERE vehicle_id = ? ORDER BY created_at DESC');
$docs->execute([$id]);
$documents = $docs->fetchAll();

$resStmt = $pdo->prepare('SELECT r.*, c.name AS client_name FROM reservations r JOIN clients c ON r.client_id = c.id WHERE r.vehicle_id = ? ORDER BY r.created_at DESC');
$resStmt->execute([$id]);
$reservations = $resStmt->fetchAll();

$totalRevenue = array_sum(array_column($reservations, 'total_price'));
$activeReservation = array_filter($reservations, fn($r) => $r['status'] === 'active');
$activeReservation = reset($activeReservation) ?: null;

$success = getFlash('success');
$error = getFlash('error');

$pageTitle = e($v['brand']) . ' ' . e($v['model']);
require_once __DIR__ . '/../includes/header.php';

$badge = ['available' => 'bg-green-500/10 text-green-400 border-green-500/30', 'rented' => 'bg-sky-500/10 text-sky-400 border-sky-500/30', 'maintenance' => 'bg-red-500/10 text-red-400 border-red-500/30'];
$badgeCls = $badge[$v['status']] ?? 'bg-gray-500/10 text-gray-400';
?>

<div class="space-y-6">
    <?php if ($success): ?>
        <div
            class="flex items-center gap-3 bg-green-500/10 border border-green-500/30 text-green-400 rounded-lg px-5 py-3 text-sm">
            <svg class="w-4 h-4 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
            </svg>
            <?= e($success) ?>
        </div>
    <?php endif; ?>

    <!-- Breadcrumb -->
    <div class="flex items-center gap-3 text-sm text-mb-subtle">
        <a href="index.php" class="hover:text-white transition-colors">Vehicles</a>
        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
        </svg>
        <span class="text-white">
            <?= e($v['brand']) ?>
            <?= e($v['model']) ?>
        </span>
    </div>

    <!-- Hero -->
    <div class="bg-mb-surface border border-mb-subtle/20 rounded-xl overflow-hidden">
        <div class="grid md:grid-cols-5">
            <!-- Image -->
            <div class="md:col-span-2 h-64 md:h-auto bg-mb-black relative">
                <?php if ($v['image_url']): ?>
                    <img src="<?= e($v['image_url']) ?>" class="w-full h-full object-cover">
                <?php else: ?>
                    <div class="w-full h-full min-h-64 flex items-center justify-center">
                        <svg class="w-20 h-20 text-mb-subtle/20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1"
                                d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                        </svg>
                    </div>
                <?php endif; ?>
            </div>
            <!-- Info -->
            <div class="md:col-span-3 p-7 space-y-5">
                <div class="flex items-start justify-between">
                    <div>
                        <h2 class="text-white text-2xl font-light">
                            <?= e($v['brand']) ?>
                            <?= e($v['model']) ?>
                        </h2>
                        <p class="text-mb-silver text-sm mt-1">
                            <?= e($v['year']) ?> &bull;
                            <?= e($v['license_plate']) ?>
                            <?= $v['color'] ? ' &bull; ' . e($v['color']) : '' ?>
                        </p>
                    </div>
                    <span class="px-3 py-1.5 rounded-full text-sm border <?= $badgeCls ?>">
                        <?= ucfirst($v['status']) ?>
                    </span>
                </div>

                <!-- Stats -->
                <div class="grid grid-cols-3 gap-4 text-center">
                    <div class="bg-mb-black/40 rounded-xl p-4">
                        <p class="text-mb-subtle text-xs uppercase">Daily Rate</p>
                        <p class="text-mb-accent text-2xl font-light mt-1">$
                            <?= number_format($v['daily_rate'], 0) ?>
                        </p>
                    </div>
                    <div class="bg-mb-black/40 rounded-xl p-4">
                        <p class="text-mb-subtle text-xs uppercase">Monthly</p>
                        <p class="text-white text-2xl font-light mt-1">
                            <?= $v['monthly_rate'] ? '$' . number_format($v['monthly_rate'], 0) : '—' ?>
                        </p>
                    </div>
                    <div class="bg-mb-black/40 rounded-xl p-4">
                        <p class="text-mb-subtle text-xs uppercase">Total Revenue</p>
                        <p class="text-green-400 text-2xl font-light mt-1">$
                            <?= number_format($totalRevenue, 0) ?>
                        </p>
                    </div>
                </div>

                <!-- Actions -->
                <div class="flex items-center gap-3 flex-wrap">
                    <a href="edit.php?id=<?= $v['id'] ?>"
                        class="bg-mb-accent text-white px-5 py-2 rounded-full hover:bg-mb-accent/80 transition-colors text-sm font-medium">Edit
                        Vehicle</a>
                    <?php if ($v['status'] !== 'rented'): ?>
                        <a href="delete.php?id=<?= $v['id'] ?>"
                            onclick="return confirm('Remove this vehicle from the fleet?')"
                            class="border border-red-500/30 text-red-400 px-5 py-2 rounded-full hover:bg-red-500/10 transition-colors text-sm">Delete</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Documents -->
        <div class="bg-mb-surface border border-mb-subtle/20 rounded-xl overflow-hidden">
            <div class="px-6 py-4 border-b border-mb-subtle/10 flex items-center justify-between">
                <h3 class="text-white font-light">Documents <span class="text-mb-subtle text-sm ml-2">
                        <?= count($documents) ?> files
                    </span></h3>
            </div>
            <?php if (empty($documents)): ?>
                <p class="py-10 text-center text-mb-subtle text-sm italic">No documents uploaded yet.</p>
            <?php else: ?>
                <div class="p-4 space-y-2">
                    <?php foreach ($documents as $doc): ?>
                        <div class="flex items-center gap-3 p-3 bg-mb-black/30 rounded-lg">
                            <svg class="w-8 h-8 text-mb-accent flex-shrink-0" fill="none" stroke="currentColor"
                                viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                                    d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                            </svg>
                            <div class="flex-1 min-w-0">
                                <p class="text-white text-sm truncate">
                                    <?= e($doc['title']) ?>
                                </p>
                                <p class="text-mb-subtle text-xs uppercase">
                                    <?= e($doc['type']) ?>
                                </p>
                            </div>
                            <a href="../<?= e($doc['file_path']) ?>" target="_blank"
                                class="text-mb-accent hover:text-white transition-colors text-xs">View</a>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Rental History -->
        <div class="bg-mb-surface border border-mb-subtle/20 rounded-xl overflow-hidden">
            <div class="px-6 py-4 border-b border-mb-subtle/10">
                <h3 class="text-white font-light">Rental History <span class="text-mb-subtle text-sm ml-2">
                        <?= count($reservations) ?> trips
                    </span></h3>
            </div>
            <?php if (empty($reservations)): ?>
                <p class="py-10 text-center text-mb-subtle text-sm italic">No rental history yet.</p>
            <?php else: ?>
                <div class="overflow-x-auto">
                    <table class="w-full text-sm">
                        <thead class="border-b border-mb-subtle/10">
                            <tr class="text-mb-subtle text-xs uppercase">
                                <th class="px-6 py-3 text-left">Client</th>
                                <th class="px-6 py-3 text-left">Period</th>
                                <th class="px-6 py-3 text-right">Total</th>
                                <th class="px-6 py-3 text-left">Status</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-mb-subtle/10">
                            <?php foreach ($reservations as $r): ?>
                                <tr class="hover:bg-mb-black/30 transition-colors">
                                    <td class="px-6 py-3 text-white">
                                        <?= e($r['client_name']) ?>
                                    </td>
                                    <td class="px-6 py-3 text-mb-silver text-xs">
                                        <?= e($r['start_date']) ?> →
                                        <?= e($r['end_date']) ?>
                                    </td>
                                    <td class="px-6 py-3 text-right text-mb-accent">$
                                        <?= number_format($r['total_price'], 0) ?>
                                    </td>
                                    <td class="px-6 py-3"><span class="text-xs capitalize">
                                            <?= e($r['status']) ?>
                                        </span></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>