<?php
require_once __DIR__ . '/../config/db.php';
$pdo = db();

$clients = $pdo->query("SELECT id, name FROM clients WHERE is_blacklisted=0 ORDER BY name")->fetchAll();
$vehicles = $pdo->query("SELECT id, brand, model, license_plate, daily_rate, monthly_rate FROM vehicles WHERE status='available' ORDER BY brand")->fetchAll();

$hiddenCount = $pdo->query("SELECT COUNT(*) FROM clients WHERE is_blacklisted=1")->fetchColumn();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $clientId = (int) ($_POST['client_id'] ?? 0);
    $vehicleId = (int) ($_POST['vehicle_id'] ?? 0);
    $rentalType = $_POST['rental_type'] ?? 'daily';
    $startDate = $_POST['start_date'] ?? '';
    $endDate = $_POST['end_date'] ?? '';
    $totalPrice = (float) ($_POST['total_price'] ?? 0);

    if (!$clientId)
        $errors['client_id'] = 'Please select a client.';
    if (!$vehicleId)
        $errors['vehicle_id'] = 'Please select a vehicle.';
    if (!$startDate)
        $errors['start_date'] = 'Start date is required.';
    if (!$endDate)
        $errors['end_date'] = 'End date is required.';
    if ($startDate && $endDate && $endDate <= $startDate)
        $errors['end_date'] = 'End date must be after start date.';
    if ($totalPrice <= 0)
        $errors['total_price'] = 'Total price must be greater than 0.';

    // Guard: reject blacklisted
    if (!isset($errors['client_id'])) {
        $chk = $pdo->prepare('SELECT is_blacklisted FROM clients WHERE id=?');
        $chk->execute([$clientId]);
        $cl = $chk->fetch();
        if ($cl && $cl['is_blacklisted'])
            $errors['client_id'] = 'This client is blacklisted and cannot make reservations.';
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare('INSERT INTO reservations (client_id,vehicle_id,rental_type,start_date,end_date,total_price,status) VALUES (?,?,?,?,?,?,?)');
        $stmt->execute([$clientId, $vehicleId, $rentalType, $startDate, $endDate, $totalPrice, 'confirmed']);
        $id = $pdo->lastInsertId();
        // Get client name
        $cn = $pdo->prepare('SELECT name FROM clients WHERE id=?');
        $cn->execute([$clientId]);
        $clientName = $cn->fetchColumn();
        flash('success', "Reservation confirmed for $clientName.");
        redirect("show.php?id=$id");
    }
}

$pageTitle = 'New Reservation';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="max-w-3xl mx-auto space-y-6">
    <div class="flex items-center gap-3 text-sm text-mb-subtle">
        <a href="index.php" class="hover:text-white transition-colors">Reservations</a>
        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
        </svg>
        <span class="text-white">New Reservation</span>
    </div>

    <?php if ($hiddenCount > 0): ?>
        <div
            class="bg-yellow-500/10 border border-yellow-500/20 rounded-lg px-5 py-3 text-yellow-400 text-sm flex items-center gap-2">
            <svg class="w-4 h-4 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
            <?= $hiddenCount ?> blacklisted client(s) are hidden from selection.
        </div>
    <?php endif; ?>

    <?php if ($errors): ?>
        <div class="bg-red-500/10 border border-red-500/30 rounded-lg p-4 text-sm text-red-400 space-y-1">
            <?php foreach ($errors as $e): ?>
                <p>&bull;
                    <?= e($e) ?>
                </p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <form method="POST" class="space-y-6" id="resForm">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <!-- Main Form -->
            <div class="lg:col-span-2 space-y-6">
                <div class="bg-mb-surface border border-mb-subtle/20 rounded-xl p-6 space-y-5">
                    <h3 class="text-white font-light text-lg border-l-2 border-mb-accent pl-3">Reservation Details</h3>

                    <div>
                        <label class="block text-sm text-mb-silver mb-2">Client <span
                                class="text-red-400">*</span></label>
                        <select name="client_id" id="clientSelect"
                            class="select2 w-full bg-mb-black border border-mb-subtle/20 rounded-lg px-4 py-3 text-white text-sm"
                            required>
                            <option value="">-- Select Client --</option>
                            <?php foreach ($clients as $cl): ?>
                                <option value="<?= $cl['id'] ?>" <?= (($_POST['client_id'] ?? '') == $cl['id']) ? 'selected' : '' ?>>
                                    <?= e($cl['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <?php if (isset($errors['client_id'])): ?>
                            <p class="text-red-400 text-xs mt-1">
                                <?= e($errors['client_id']) ?>
                            </p>
                        <?php endif; ?>
                    </div>

                    <div>
                        <label class="block text-sm text-mb-silver mb-2">Vehicle <span
                                class="text-red-400">*</span></label>
                        <select name="vehicle_id" id="vehicleSelect"
                            class="select2 w-full bg-mb-black border border-mb-subtle/20 rounded-lg px-4 py-3 text-white text-sm"
                            required>
                            <option value="">-- Select Available Vehicle --</option>
                            <?php foreach ($vehicles as $v): ?>
                                <option value="<?= $v['id'] ?>" data-daily="<?= $v['daily_rate'] ?>"
                                    data-monthly="<?= $v['monthly_rate'] ?? '' ?>"
                                    <?= (($_POST['vehicle_id'] ?? '') == $v['id']) ? 'selected' : '' ?>>
                                    <?= e($v['brand']) ?>
                                    <?= e($v['model']) ?> —
                                    <?= e($v['license_plate']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <?php if (isset($errors['vehicle_id'])): ?>
                            <p class="text-red-400 text-xs mt-1">
                                <?= e($errors['vehicle_id']) ?>
                            </p>
                        <?php endif; ?>
                    </div>

                    <div>
                        <label class="block text-sm text-mb-silver mb-2">Rental Type</label>
                        <div class="flex gap-4">
                            <?php foreach (['daily' => 'Daily', 'monthly' => 'Monthly'] as $val => $lbl): ?>
                                <label class="flex items-center gap-2 cursor-pointer">
                                    <input type="radio" name="rental_type" value="<?= $val ?>"
                                        <?= (($_POST['rental_type'] ?? 'daily') === $val) ? 'checked' : '' ?>
                                    class="accent-mb-accent">
                                    <span class="text-mb-silver text-sm">
                                        <?= $lbl ?>
                                    </span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm text-mb-silver mb-2">Start Date <span
                                    class="text-red-400">*</span></label>
                            <input type="date" name="start_date" id="startDate"
                                value="<?= e($_POST['start_date'] ?? date('Y-m-d')) ?>" required
                                class="w-full bg-mb-black border border-mb-subtle/20 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-mb-accent text-sm">
                        </div>
                        <div>
                            <label class="block text-sm text-mb-silver mb-2">End Date <span
                                    class="text-red-400">*</span></label>
                            <input type="date" name="end_date" id="endDate" value="<?= e($_POST['end_date'] ?? '') ?>"
                                required
                                class="w-full bg-mb-black border border-mb-subtle/20 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-mb-accent text-sm">
                            <?php if (isset($errors['end_date'])): ?>
                                <p class="text-red-400 text-xs mt-1">
                                    <?= e($errors['end_date']) ?>
                                </p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div>
                        <label class="block text-sm text-mb-silver mb-2">Total Price (USD) <span
                                class="text-red-400">*</span></label>
                        <input type="number" name="total_price" id="totalPrice"
                            value="<?= e($_POST['total_price'] ?? '') ?>" step="0.01" min="0" required
                            class="w-full bg-mb-black border border-mb-subtle/20 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-mb-accent text-sm">
                    </div>
                </div>
            </div>

            <!-- Price Calculator -->
            <div class="space-y-4">
                <div class="bg-mb-surface border border-mb-subtle/20 rounded-xl p-5 space-y-3" id="vehicleInfo"
                    style="display:none">
                    <h4 class="text-white font-light text-sm border-l-2 border-mb-accent pl-3">Vehicle Info</h4>
                    <p id="vName" class="text-mb-silver text-sm"></p>
                    <div class="flex justify-between text-xs text-mb-subtle">
                        <span>Daily Rate</span><span id="vDaily" class="text-mb-accent">—</span>
                    </div>
                    <div class="flex justify-between text-xs text-mb-subtle">
                        <span>Monthly Rate</span><span id="vMonthly" class="text-white">—</span>
                    </div>
                </div>

                <div class="bg-mb-surface border border-mb-subtle/20 rounded-xl p-5 space-y-3" id="priceCalc">
                    <h4 class="text-white font-light text-sm border-l-2 border-yellow-400 pl-3">Price Breakdown</h4>
                    <div class="flex justify-between text-xs text-mb-subtle"><span>Days</span><span
                            id="calcDays">—</span></div>
                    <div class="flex justify-between text-xs text-mb-subtle"><span>Rate/Day</span><span
                            id="calcRate">—</span></div>
                    <div class="border-t border-mb-subtle/20 pt-2 flex justify-between text-sm font-medium">
                        <span class="text-mb-silver">Estimated Total</span>
                        <span class="text-mb-accent" id="calcTotal">$0</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="flex items-center justify-end gap-4">
            <a href="index.php" class="text-mb-silver hover:text-white transition-colors text-sm">Cancel</a>
            <button type="submit"
                class="bg-mb-accent text-white px-8 py-3 rounded-full hover:bg-mb-accent/80 transition-colors font-medium shadow-lg shadow-mb-accent/20">
                Confirm Reservation
            </button>
        </div>
    </form>
</div>

<?php
$extraScripts = <<<JS
<script>
const vehicleSelect = document.getElementById('vehicleSelect');
const startDate = document.getElementById('startDate');
const endDate = document.getElementById('endDate');
const totalPrice = document.getElementById('totalPrice');

function calcPrice() {
    const opt = vehicleSelect.options[vehicleSelect.selectedIndex];
    const daily = parseFloat(opt.dataset.daily || 0);
    const s = new Date(startDate.value);
    const e = new Date(endDate.value);
    if (!daily || isNaN(s) || isNaN(e) || e <= s) return;
    const days = Math.ceil((e - s) / 86400000);
    const total = days * daily;
    document.getElementById('calcDays').textContent = days;
    document.getElementById('calcRate').textContent = '$' + daily.toFixed(2);
    document.getElementById('calcTotal').textContent = '$' + total.toFixed(2);
    totalPrice.value = total.toFixed(2);
}

function updateVehicleInfo() {
    const opt = vehicleSelect.options[vehicleSelect.selectedIndex];
    const info = document.getElementById('vehicleInfo');
    if (!opt.value) { info.style.display='none'; return; }
    info.style.display='block';
    document.getElementById('vName').textContent = opt.text;
    document.getElementById('vDaily').textContent = '$' + parseFloat(opt.dataset.daily||0).toFixed(0) + '/day';
    document.getElementById('vMonthly').textContent = opt.dataset.monthly ? '$' + parseFloat(opt.dataset.monthly).toFixed(0) + '/mo' : '—';
    calcPrice();
}

$(vehicleSelect).on('change', updateVehicleInfo);
startDate.addEventListener('change', calcPrice);
endDate.addEventListener('change', calcPrice);
</script>
JS;
require_once __DIR__ . '/../includes/footer.php';
?>