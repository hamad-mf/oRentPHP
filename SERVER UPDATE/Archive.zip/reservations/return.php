<?php
require_once __DIR__ . '/../config/db.php';
$id = (int) ($_GET['id'] ?? 0);
$pdo = db();

$rStmt = $pdo->prepare('SELECT r.*, c.name AS client_name, v.brand, v.model, v.license_plate, v.daily_rate FROM reservations r JOIN clients c ON r.client_id=c.id JOIN vehicles v ON r.vehicle_id=v.id WHERE r.id=?');
$rStmt->execute([$id]);
$r = $rStmt->fetch();
if (!$r || $r['status'] !== 'active') {
    flash('error', 'Only active reservations can be returned.');
    redirect('index.php');
}

$iStmt = $pdo->prepare("SELECT * FROM vehicle_inspections WHERE reservation_id=? AND type='delivery' LIMIT 1");
$iStmt->execute([$id]);
$delivery = $iStmt->fetch();

// Calculate overdue
$today = new DateTime(date('Y-m-d'));
$endDate = new DateTime($r['end_date']);
$overdueDays = 0;
$overdueAmt = 0;
if ($today > $endDate) {
    $overdueDays = (int) $today->diff($endDate)->days;
    $overdueAmt = $overdueDays * (float) $r['daily_rate'];
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fuel = (int) ($_POST['fuel_level'] ?? 100);
    $miles = (int) ($_POST['mileage'] ?? 0);
    $notes = trim($_POST['notes'] ?? '');

    if ($fuel < 0 || $fuel > 100)
        $errors['fuel_level'] = 'Fuel level must be 0–100.';
    if ($miles < 0)
        $errors['mileage'] = 'Mileage must be 0 or more.';

    if (empty($errors)) {
        $iStmt2 = $pdo->prepare('INSERT INTO vehicle_inspections (reservation_id,type,fuel_level,mileage,notes) VALUES (?,?,?,?,?)');
        $iStmt2->execute([$id, 'return', $fuel, $miles, $notes]);
        $pdo->prepare("UPDATE reservations SET status='completed', actual_end_date=?, overdue_amount=? WHERE id=?")
            ->execute([date('Y-m-d'), $overdueAmt, $id]);
        $pdo->prepare("UPDATE vehicles SET status='available' WHERE id=?")->execute([$r['vehicle_id']]);
        $msg = 'Vehicle returned successfully. Reservation closed.';
        if ($overdueAmt > 0)
            $msg .= " ⚠ Overdue charge: $" . number_format($overdueAmt, 2) . " ($overdueDays extra days)";
        flash('success', $msg);
        redirect("show.php?id=$id");
    }
}

$pageTitle = 'Process Return';
require_once __DIR__ . '/../includes/header.php';
?>
<div class="max-w-4xl mx-auto space-y-6">
    <div class="flex items-center gap-3 text-sm text-mb-subtle">
        <a href="show.php?id=<?= $id ?>" class="hover:text-white transition-colors">Reservation #<?= $id ?></a>
        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
        </svg>
        <span class="text-white">Process Return</span>
    </div>

    <?php if ($overdueDays > 0): ?>
        <div class="bg-red-500/10 border border-red-500/30 rounded-xl p-4 text-red-400 text-sm">
            <p class="font-medium">⚠ Overdue by <?= $overdueDays ?> day(s)</p>
            <p class="mt-1">Additional charge: <strong>$<?= number_format($overdueAmt, 2) ?></strong> will be applied.</p>
        </div>
    <?php endif; ?>

    <?php if ($errors): ?>
        <div class="bg-red-500/10 border border-red-500/30 rounded-lg p-4 text-sm text-red-400">
            <?php foreach ($errors as $e): ?>
                <p>&bull; <?= e($e) ?></p><?php endforeach; ?>
        </div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data" class="space-y-8">
        <!-- Header Info -->
        <div class="bg-mb-surface border border-mb-subtle/20 rounded-lg p-6 grid grid-cols-1 md:grid-cols-4 gap-6">
            <div>
                <span class="block text-mb-subtle text-xs uppercase mb-1">Client</span>
                <p class="text-white text-lg font-light"><?= e($r['client_name']) ?></p>
            </div>
            <div>
                <span class="block text-mb-subtle text-xs uppercase mb-1">Vehicle</span>
                <p class="text-white text-lg font-light"><?= e($r['brand']) ?> <?= e($r['model']) ?></p>
            </div>
            <div>
                <span class="block text-mb-subtle text-xs uppercase mb-1">Due Date</span>
                <p class="text-white text-lg font-light"><?= date('M d, Y', strtotime($r['end_date'])) ?></p>
            </div>
            <div>
                <span class="block text-mb-subtle text-xs uppercase mb-1">Status</span>
                <span class="text-green-400 text-lg font-light">On Rent</span>
            </div>
        </div>

        <?php if ($delivery): ?>
            <div class="bg-mb-surface border border-mb-subtle/20 rounded-xl p-4 text-sm">
                <p class="text-mb-subtle text-xs uppercase mb-2">At Delivery</p>
                <div class="flex gap-6">
                    <div>
                        <p class="text-mb-subtle text-xs">Mileage</p>
                        <p class="text-white"><?= number_format($delivery['mileage']) ?> km</p>
                    </div>
                    <div>
                        <p class="text-mb-subtle text-xs">Fuel</p>
                        <p class="text-white"><?= $delivery['fuel_level'] ?>%</p>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <!-- Readings -->
            <div class="space-y-6">
                <h3 class="text-white text-lg font-light border-l-2 border-green-500 pl-3">Return Readings</h3>
                <div>
                    <label for="mileage" class="block text-sm font-medium text-mb-silver mb-2">Return Mileage
                        (km)</label>
                    <input type="number" name="mileage" id="mileage" required
                        class="w-full bg-mb-surface border border-mb-subtle/20 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-mb-accent transition-colors"
                        placeholder="e.g. 15500" value="<?= e($_POST['mileage'] ?? '') ?>">
                </div>
                <div>
                    <label for="fuel_level" class="block text-sm font-medium text-mb-silver mb-2">Return Fuel Level
                        (%)</label>
                    <div class="relative pt-1">
                        <input type="range" name="fuel_level" id="fuelSlider" min="0" max="100"
                            value="<?= e($_POST['fuel_level'] ?? 100) ?>"
                            class="w-full h-2 bg-mb-subtle/50 rounded-lg appearance-none cursor-pointer accent-green-500"
                            oninput="document.getElementById('fuel-val').innerText = this.value + '%'">
                        <span id="fuel-val"
                            class="absolute right-0 top-0 text-green-500 text-sm font-bold"><?= e($_POST['fuel_level'] ?? 100) ?>%</span>
                    </div>
                    <div class="h-2 bg-mb-black/60 rounded-full overflow-hidden mt-3">
                        <div id="fuelBar" class="h-2 bg-green-500 rounded-full transition-all"
                            style="width:<?= e($_POST['fuel_level'] ?? 100) ?>%"></div>
                    </div>
                </div>
                <div>
                    <label for="notes" class="block text-sm font-medium text-mb-silver mb-2">Return Inspection
                        Notes</label>
                    <textarea name="notes" id="notes" rows="4"
                        class="w-full bg-mb-surface border border-mb-subtle/20 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-mb-accent transition-colors"
                        placeholder="Any new damage or issues found?"><?= e($_POST['notes'] ?? '') ?></textarea>
                </div>
            </div>

            <!-- Photos -->
            <div class="space-y-4">
                <h3 class="text-white text-lg font-light border-l-2 border-green-500 pl-3">Return Condition Photos</h3>
                <p class="text-xs text-mb-subtle">Upload clear photos to document return condition.</p>
                <?php foreach (['Front', 'Back', 'Left', 'Right', 'Interior'] as $area): ?>
                    <div
                        class="bg-mb-black/30 p-4 rounded-lg border border-mb-subtle/10 hover:border-green-500/30 transition-colors">
                        <label class="block text-sm font-medium text-mb-silver mb-2"><?= $area ?> View</label>
                        <input type="file" name="photos[<?= strtolower($area) ?>]" accept="image/*" class="block w-full text-sm text-mb-silver
                                   file:mr-4 file:py-2 file:px-4
                                   file:rounded-full file:border-0
                                   file:text-xs file:font-semibold
                                   file:bg-mb-surface file:text-green-500
                                   hover:file:bg-mb-surface/80 cursor-pointer">
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="flex items-center justify-end gap-4 pt-8 border-t border-mb-subtle/10">
            <a href="show.php?id=<?= $id ?>" class="text-mb-silver hover:text-white transition-colors">Cancel</a>
            <button type="submit"
                class="bg-green-600 text-white px-8 py-3 rounded-full hover:bg-green-500 transition-colors font-medium shadow-lg shadow-green-900/20">
                Complete Return
            </button>
        </div>
    </form>
</div>
<?php
$extraScripts = '<script>
const slider = document.getElementById("fuelSlider");
const valEl  = document.getElementById("fuelVal");
const barEl  = document.getElementById("fuelBar");
function updateFuel(v){valEl.textContent=v;barEl.style.width=v+"%";barEl.className="h-2 rounded-full "+(v>=75?"bg-green-500":v>=50?"bg-yellow-400":v>=25?"bg-orange-400":"bg-red-500");}
slider.addEventListener("input",()=>updateFuel(slider.value));
updateFuel(slider.value);
</script>';
require_once __DIR__ . '/../includes/footer.php';
?>