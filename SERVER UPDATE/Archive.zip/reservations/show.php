<?php
require_once __DIR__ . '/../config/db.php';
$id = (int) ($_GET['id'] ?? 0);
$pdo = db();

$rStmt = $pdo->prepare('SELECT r.*, c.name AS client_name, c.id AS cid, v.brand, v.model, v.license_plate, v.daily_rate, v.image_url FROM reservations r JOIN clients c ON r.client_id=c.id JOIN vehicles v ON r.vehicle_id=v.id WHERE r.id=?');
$rStmt->execute([$id]);
$r = $rStmt->fetch();
if (!$r) {
    flash('error', 'Reservation not found.');
    redirect('index.php');
}

$iStmt = $pdo->prepare('SELECT * FROM vehicle_inspections WHERE reservation_id=? ORDER BY created_at');
$iStmt->execute([$id]);
$inspections = $iStmt->fetchAll();
$delivery = null;
$return = null;
foreach ($inspections as $ins) {
    if ($ins['type'] === 'delivery')
        $delivery = $ins;
    if ($ins['type'] === 'return')
        $return = $ins;
}

$days = durationDays($r['start_date'], $r['end_date']);
$overdue = isOverdue($r['end_date'], $r['status']);
$overdueAmt = $r['overdue_amount'];
$grandTotal = $r['total_price'] + $overdueAmt;

$success = getFlash('success');
$pageTitle = 'Reservation #' . $id;
require_once __DIR__ . '/../includes/header.php';

$statusColors = ['pending' => 'bg-yellow-500/10 text-yellow-400 border-yellow-500/30', 'confirmed' => 'bg-sky-500/10 text-sky-400 border-sky-500/30', 'active' => 'bg-green-500/10 text-green-400 border-green-500/30', 'completed' => 'bg-mb-subtle/10 text-mb-subtle border-mb-subtle/30'];
$sc = $statusColors[$r['status']] ?? '';

function fuelBar(int $pct): string
{
    $color = $pct >= 75 ? 'bg-green-500' : ($pct >= 50 ? 'bg-yellow-400' : ($pct >= 25 ? 'bg-orange-400' : 'bg-red-500'));
    return "<div class='w-full h-2 bg-mb-black/60 rounded-full overflow-hidden'><div class='h-2 $color rounded-full' style='width:{$pct}%'></div></div>";
}
?>

<div class="space-y-6">
    <?php if ($success): ?>
        <div
            class="flex items-center gap-3 bg-green-500/10 border border-green-500/30 text-green-400 rounded-lg px-5 py-3 text-sm">
            <svg class="w-4 h-4 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
            </svg>
            <?= e($success) ?>
        </div>
    <?php endif; ?>

    <div class="flex items-center justify-between flex-wrap gap-4">
        <div class="flex items-center gap-3 text-sm text-mb-subtle">
            <a href="index.php" class="hover:text-white transition-colors">Reservations</a>
            <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
            </svg>
            <span class="text-white">Reservation #
                <?= $id ?>
            </span>
        </div>
        <!-- Actions -->
        <div class="flex items-center gap-3 flex-wrap">
            <?php if (in_array($r['status'], ['pending', 'confirmed'])): ?>
                <a href="edit.php?id=<?= $id ?>"
                    class="border border-mb-subtle/30 text-mb-silver px-4 py-2 rounded-full hover:border-white/30 hover:text-white transition-all text-sm">Edit</a>
            <?php endif; ?>
            <?php if ($r['status'] === 'confirmed'): ?>
                <a href="deliver.php?id=<?= $id ?>"
                    class="bg-green-600 text-white px-5 py-2 rounded-full hover:bg-green-500 transition-colors text-sm font-medium">▶
                    Deliver Vehicle</a>
            <?php endif; ?>
            <?php if ($r['status'] === 'active'): ?>
                <a href="return.php?id=<?= $id ?>"
                    class="bg-mb-accent text-white px-5 py-2 rounded-full hover:bg-mb-accent/80 transition-colors text-sm font-medium">⏎
                    Process Return</a>
            <?php endif; ?>
            <?php if (!in_array($r['status'], ['active', 'completed'])): ?>
                <a href="delete.php?id=<?= $id ?>" onclick="return confirm('Cancel this reservation?')"
                    class="border border-red-500/30 text-red-400 px-4 py-2 rounded-full hover:bg-red-500/10 transition-colors text-sm">Cancel</a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Main Info -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div class="lg:col-span-2 bg-mb-surface border border-mb-subtle/20 rounded-xl p-6 space-y-5">
            <div class="flex items-start justify-between">
                <h2 class="text-white text-xl font-light">Reservation #
                    <?= $id ?>
                </h2>
                <div class="flex items-center gap-2">
                    <span class="px-3 py-1.5 rounded-full text-sm border capitalize <?= $sc ?>">
                        <?= e($r['status']) ?>
                    </span>
                    <?php if ($overdue): ?>
                        <span
                            class="px-3 py-1.5 rounded-full text-sm border bg-red-500/20 text-red-400 border-red-500/30 animate-pulse">⚠
                            Overdue</span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="grid grid-cols-2 gap-4 text-sm">
                <div class="bg-mb-black/40 rounded-xl p-4">
                    <p class="text-mb-subtle text-xs uppercase mb-1">Client</p>
                    <a href="../clients/show.php?id=<?= $r['cid'] ?>"
                        class="text-white hover:text-mb-accent transition-colors">
                        <?= e($r['client_name']) ?>
                    </a>
                </div>
                <div class="bg-mb-black/40 rounded-xl p-4">
                    <p class="text-mb-subtle text-xs uppercase mb-1">Vehicle</p>
                    <a href="../vehicles/show.php?id=<?= $r['vehicle_id'] ?>"
                        class="text-white hover:text-mb-accent transition-colors">
                        <?= e($r['brand']) ?>
                        <?= e($r['model']) ?>
                    </a>
                    <p class="text-xs text-mb-subtle">
                        <?= e($r['license_plate']) ?>
                    </p>
                </div>
                <div class="bg-mb-black/40 rounded-xl p-4">
                    <p class="text-mb-subtle text-xs uppercase mb-1">Period</p>
                    <p class="text-white">
                        <?= e($r['start_date']) ?> →
                        <?= e($r['end_date']) ?>
                    </p>
                    <p class="text-xs text-mb-subtle">
                        <?= $days ?> days &bull;
                        <?= ucfirst($r['rental_type']) ?>
                    </p>
                </div>
                <div class="bg-mb-black/40 rounded-xl p-4">
                    <p class="text-mb-subtle text-xs uppercase mb-1">Daily Rate</p>
                    <p class="text-mb-accent text-xl font-light">$
                        <?= number_format($r['daily_rate'], 0) ?>
                    </p>
                </div>
            </div>

            <!-- Pricing Summary -->
            <div class="border-t border-mb-subtle/10 pt-4 space-y-2">
                <div class="flex justify-between text-sm"><span class="text-mb-subtle">Base Price</span><span
                        class="text-white">$
                        <?= number_format($r['total_price'], 2) ?>
                    </span></div>
                <?php if ($overdueAmt > 0): ?>
                    <div class="flex justify-between text-sm"><span class="text-red-400">Overdue Charge</span><span
                            class="text-red-400">+$
                            <?= number_format($overdueAmt, 2) ?>
                        </span></div>
                <?php endif; ?>
                <div class="flex justify-between font-medium text-base border-t border-mb-subtle/10 pt-2">
                    <span class="text-mb-silver">Grand Total</span>
                    <span class="text-mb-accent">$
                        <?= number_format($grandTotal, 2) ?>
                    </span>
                </div>
            </div>
        </div>

        <!-- Vehicle side info -->
        <div class="bg-mb-surface border border-mb-subtle/20 rounded-xl overflow-hidden">
            <?php if ($r['image_url']): ?>
                <img src="<?= e($r['image_url']) ?>" class="w-full h-36 object-cover">
            <?php endif; ?>
            <div class="p-5">
                <p class="text-white font-light">
                    <?= e($r['brand']) ?>
                    <?= e($r['model']) ?>
                </p>
                <p class="text-mb-subtle text-xs mt-1">
                    <?= e($r['license_plate']) ?>
                </p>
                <p class="text-mb-accent text-sm mt-2">$
                    <?= number_format($r['daily_rate'], 0) ?>/day
                </p>
            </div>
        </div>
    </div>

    <!-- Inspections -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <!-- Delivery Inspection -->
        <div class="bg-mb-surface border border-mb-subtle/20 rounded-xl overflow-hidden">
            <div class="px-6 py-4 border-b border-mb-subtle/10 bg-green-500/5">
                <h3 class="text-green-400 font-light flex items-center gap-2">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                    </svg>
                    Delivery Inspection
                </h3>
            </div>
            <?php if ($delivery): ?>
                <div class="p-5 space-y-3 text-sm">
                    <div class="flex justify-between"><span class="text-mb-subtle">Mileage</span><span class="text-white">
                            <?= number_format($delivery['mileage']) ?> km
                        </span></div>
                    <div>
                        <div class="flex justify-between mb-1"><span class="text-mb-subtle">Fuel Level</span><span
                                class="text-white">
                                <?= $delivery['fuel_level'] ?>%
                            </span></div>
                        <?= fuelBar($delivery['fuel_level']) ?>
                    </div>
                    <?php if ($delivery['notes']): ?>
                        <p class="text-mb-subtle text-xs italic">
                            <?= e($delivery['notes']) ?>
                        </p>
                    <?php endif; ?>
                    <p class="text-mb-subtle text-xs">
                        <?= e($delivery['created_at']) ?>
                    </p>
                </div>
            <?php else: ?>
                <p class="py-8 text-center text-mb-subtle text-sm italic">Not delivered yet.</p>
            <?php endif; ?>
        </div>

        <!-- Return Inspection -->
        <div class="bg-mb-surface border border-mb-subtle/20 rounded-xl overflow-hidden">
            <div class="px-6 py-4 border-b border-mb-subtle/10 bg-mb-accent/5">
                <h3 class="text-mb-accent font-light flex items-center gap-2">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6" />
                    </svg>
                    Return Inspection
                </h3>
            </div>
            <?php if ($return): ?>
                <div class="p-5 space-y-3 text-sm">
                    <div class="flex justify-between"><span class="text-mb-subtle">Mileage</span><span class="text-white">
                            <?= number_format($return['mileage']) ?> km
                        </span></div>
                    <div>
                        <div class="flex justify-between mb-1"><span class="text-mb-subtle">Fuel Level</span><span
                                class="text-white">
                                <?= $return['fuel_level'] ?>%
                            </span></div>
                        <?= fuelBar($return['fuel_level']) ?>
                    </div>
                    <?php if ($return['notes']): ?>
                        <p class="text-mb-subtle text-xs italic">
                            <?= e($return['notes']) ?>
                        </p>
                    <?php endif; ?>
                    <p class="text-mb-subtle text-xs">
                        <?= e($return['created_at']) ?>
                    </p>
                </div>
            <?php else: ?>
                <p class="py-8 text-center text-mb-subtle text-sm italic">Not returned yet.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>