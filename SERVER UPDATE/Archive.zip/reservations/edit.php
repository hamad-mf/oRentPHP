<?php
require_once __DIR__ . '/../config/db.php';
$id = (int) ($_GET['id'] ?? 0);
$pdo = db();

$rStmt = $pdo->prepare('SELECT r.*, c.name AS client_name, v.brand, v.model, v.license_plate, v.daily_rate, v.monthly_rate FROM reservations r JOIN clients c ON r.client_id=c.id JOIN vehicles v ON r.vehicle_id=v.id WHERE r.id=?');
$rStmt->execute([$id]);
$r = $rStmt->fetch();
if (!$r) {
    flash('error', 'Reservation not found.');
    redirect('index.php');
}

if (!in_array($r['status'], ['pending', 'confirmed'])) {
    flash('error', 'Only pending or confirmed reservations can be edited.');
    redirect("show.php?id=$id");
}

$clients = $pdo->query("SELECT id,name FROM clients WHERE is_blacklisted=0 ORDER BY name")->fetchAll();
$vehicles = $pdo->query("SELECT id,brand,model,license_plate,daily_rate,monthly_rate FROM vehicles WHERE status IN ('available','rented') ORDER BY brand")->fetchAll();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $clientId = (int) ($_POST['client_id'] ?? 0);
    $vehicleId = (int) ($_POST['vehicle_id'] ?? 0);
    $rentalType = $_POST['rental_type'] ?? 'daily';
    $startDate = $_POST['start_date'] ?? '';
    $endDate = $_POST['end_date'] ?? '';
    $totalPrice = (float) ($_POST['total_price'] ?? 0);

    if (!$clientId)
        $errors['client_id'] = 'Please select a client.';
    if (!$vehicleId)
        $errors['vehicle_id'] = 'Please select a vehicle.';
    if (!$startDate)
        $errors['start_date'] = 'Start date is required.';
    if (!$endDate)
        $errors['end_date'] = 'End date is required.';
    if ($endDate && $startDate && $endDate <= $startDate)
        $errors['end_date'] = 'End date must be after start date.';

    if (!isset($errors['client_id'])) {
        $chk = $pdo->prepare('SELECT is_blacklisted FROM clients WHERE id=?');
        $chk->execute([$clientId]);
        $cl = $chk->fetch();
        if ($cl && $cl['is_blacklisted'])
            $errors['client_id'] = 'Client is blacklisted.';
    }

    if (empty($errors)) {
        $pdo->prepare('UPDATE reservations SET client_id=?,vehicle_id=?,rental_type=?,start_date=?,end_date=?,total_price=? WHERE id=?')
            ->execute([$clientId, $vehicleId, $rentalType, $startDate, $endDate, $totalPrice, $id]);
        flash('success', 'Reservation updated.');
        redirect("show.php?id=$id");
    }
    $r = array_merge($r, $_POST);
}

$pageTitle = 'Edit Reservation #' . $id;
require_once __DIR__ . '/../includes/header.php';
?>
<div class="max-w-3xl mx-auto space-y-6">
    <div class="flex items-center gap-3 text-sm text-mb-subtle">
        <a href="index.php" class="hover:text-white">Reservations</a>
        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
        </svg>
        <a href="show.php?id=<?= $id ?>" class="hover:text-white">#
            <?= $id ?>
        </a>
        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
        </svg>
        <span class="text-white">Edit</span>
    </div>

    <?php if ($errors): ?>
        <div class="bg-red-500/10 border border-red-500/30 rounded-lg p-4 text-sm text-red-400 space-y-1">
            <?php foreach ($errors as $e): ?>
                <p>&bull;
                    <?= e($e) ?>
                </p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <form method="POST" class="space-y-6" id="resForm">
        <div class="bg-mb-surface border border-mb-subtle/20 rounded-xl p-6 space-y-5">
            <h3 class="text-white font-light text-lg border-l-2 border-mb-accent pl-3">Edit Reservation</h3>
            <div>
                <label class="block text-sm text-mb-silver mb-2">Client <span class="text-red-400">*</span></label>
                <select name="client_id"
                    class="select2 w-full bg-mb-black border border-mb-subtle/20 rounded-lg px-4 py-3 text-white text-sm"
                    required>
                    <option value="">-- Select Client --</option>
                    <?php foreach ($clients as $cl): ?>
                        <option value="<?= $cl['id'] ?>" <?= ($r['client_id'] == $cl['id']) ? 'selected' : '' ?>>
                            <?= e($cl['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <?php if (isset($errors['client_id'])): ?>
                    <p class="text-red-400 text-xs mt-1">
                        <?= e($errors['client_id']) ?>
                    </p>
                <?php endif; ?>
            </div>
            <div>
                <label class="block text-sm text-mb-silver mb-2">Vehicle <span class="text-red-400">*</span></label>
                <select name="vehicle_id" id="vehicleSelect"
                    class="select2 w-full bg-mb-black border border-mb-subtle/20 rounded-lg px-4 py-3 text-white text-sm"
                    required>
                    <option value="">-- Select Vehicle --</option>
                    <?php foreach ($vehicles as $v): ?>
                        <option value="<?= $v['id'] ?>" data-daily="<?= $v['daily_rate'] ?>"
                            <?= ($r['vehicle_id'] == $v['id']) ? 'selected' : '' ?>>
                            <?= e($v['brand']) ?>
                            <?= e($v['model']) ?> —
                            <?= e($v['license_plate']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="flex gap-4">
                <?php foreach (['daily' => 'Daily', 'monthly' => 'Monthly'] as $val => $lbl): ?>
                    <label class="flex items-center gap-2 cursor-pointer">
                        <input type="radio" name="rental_type" value="<?= $val ?>"
                            <?= ($r['rental_type'] === $val) ? 'checked' : '' ?> class="accent-mb-accent">
                        <span class="text-mb-silver text-sm">
                            <?= $lbl ?>
                        </span>
                    </label>
                <?php endforeach; ?>
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm text-mb-silver mb-2">Start Date</label>
                    <input type="date" name="start_date" id="startDate" value="<?= e($r['start_date']) ?>" required
                        class="w-full bg-mb-black border border-mb-subtle/20 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-mb-accent text-sm">
                </div>
                <div>
                    <label class="block text-sm text-mb-silver mb-2">End Date</label>
                    <input type="date" name="end_date" id="endDate" value="<?= e($r['end_date']) ?>" required
                        class="w-full bg-mb-black border border-mb-subtle/20 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-mb-accent text-sm">
                    <?php if (isset($errors['end_date'])): ?>
                        <p class="text-red-400 text-xs mt-1">
                            <?= e($errors['end_date']) ?>
                        </p>
                    <?php endif; ?>
                </div>
            </div>
            <div>
                <label class="block text-sm text-mb-silver mb-2">Total Price (USD)</label>
                <input type="number" name="total_price" id="totalPrice" value="<?= e($r['total_price']) ?>" step="0.01"
                    min="0" required
                    class="w-full bg-mb-black border border-mb-subtle/20 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-mb-accent text-sm">
            </div>
        </div>
        <div class="flex items-center justify-end gap-4">
            <a href="show.php?id=<?= $id ?>" class="text-mb-silver hover:text-white text-sm">Cancel</a>
            <button type="submit"
                class="bg-mb-accent text-white px-8 py-3 rounded-full hover:bg-mb-accent/80 transition-colors font-medium">Save
                Changes</button>
        </div>
    </form>
</div>
<?php
$extraScripts = '<script>
const vehicleSelect = document.getElementById("vehicleSelect");
const startDate = document.getElementById("startDate");
const endDate   = document.getElementById("endDate");
const totalPrice= document.getElementById("totalPrice");
function calcPrice() {
    const opt = vehicleSelect.options[vehicleSelect.selectedIndex];
    const daily = parseFloat(opt.dataset.daily || 0);
    const s = new Date(startDate.value), e = new Date(endDate.value);
    if (!daily || isNaN(s) || isNaN(e) || e <= s) return;
    const days = Math.ceil((e-s)/86400000);
    totalPrice.value = (days * daily).toFixed(2);
}
$(vehicleSelect).on("change", calcPrice);
startDate.addEventListener("change", calcPrice);
endDate.addEventListener("change", calcPrice);
</script>';
require_once __DIR__ . '/../includes/footer.php';
?>