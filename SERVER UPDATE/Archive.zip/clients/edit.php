<?php
require_once __DIR__ . '/../config/db.php';
$id = (int) ($_GET['id'] ?? 0);
$pdo = db();
$cStmt = $pdo->prepare('SELECT * FROM clients WHERE id=?');
$cStmt->execute([$id]);
$c = $cStmt->fetch();
if (!$c) {
    flash('error', 'Client not found.');
    redirect('index.php');
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $notes = trim($_POST['notes'] ?? '');
    if (!$name)
        $errors['name'] = 'Name is required.';
    if (!$email)
        $errors['email'] = 'Email is required.';
    if ($email && !filter_var($email, FILTER_VALIDATE_EMAIL))
        $errors['email'] = 'Invalid email.';
    if (!$phone)
        $errors['phone'] = 'Phone is required.';
    if (!isset($errors['email'])) {
        $chk = $pdo->prepare('SELECT id FROM clients WHERE email=? AND id!=?');
        $chk->execute([$email, $id]);
        if ($chk->fetch())
            $errors['email'] = 'Email already used.';
    }
    if (empty($errors)) {
        $pdo->prepare('UPDATE clients SET name=?,email=?,phone=?,address=?,notes=? WHERE id=?')
            ->execute([$name, $email, $phone, $address, $notes, $id]);
        flash('success', 'Client updated successfully.');
        redirect("show.php?id=$id");
    }
    $c = array_merge($c, $_POST);
}
$pageTitle = 'Edit Client';
require_once __DIR__ . '/../includes/header.php';
?>
<div class="max-w-2xl mx-auto space-y-6">
    <div class="flex items-center gap-3 text-sm text-mb-subtle">
        <a href="index.php" class="hover:text-white transition-colors">Clients</a>
        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
        </svg>
        <a href="show.php?id=<?= $id ?>" class="hover:text-white transition-colors">
            <?= e($c['name']) ?>
        </a>
        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
        </svg>
        <span class="text-white">Edit</span>
    </div>
    <?php if ($errors): ?>
        <div class="bg-red-500/10 border border-red-500/30 rounded-lg p-4 text-sm text-red-400 space-y-1">
            <?php foreach ($errors as $e): ?>
                <p>&bull;
                    <?= e($e) ?>
                </p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    <form method="POST" class="space-y-6">
        <div class="bg-mb-surface border border-mb-subtle/20 rounded-xl p-6 space-y-5">
            <h3 class="text-white font-light text-lg border-l-2 border-mb-accent pl-3">Client Information</h3>
            <?php foreach ([['name', 'Full Name', 'text', true], ['email', 'Email', 'email', true], ['phone', 'Phone', 'text', true]] as [$n, $l, $t, $r]):
                $val = htmlspecialchars($c[$n] ?? '', ENT_QUOTES);
                $err = $errors[$n] ?? ''; ?>
                <div><label class="block text-sm text-mb-silver mb-2">
                        <?= $l ?>
                        <?= $r ? " <span class='text-red-400'>*</span>" : '' ?>
                    </label>
                    <input type="<?= $t ?>" name="<?= $n ?>" value="<?= $val ?>" <?= $r ? 'required' : '' ?>
                    class="w-full bg-mb-black border border-mb-subtle/20 rounded-lg px-4 py-3 text-white focus:outline-none
                focus:border-mb-accent transition-colors text-sm">
                    <?= $err ? "<p class='text-red-400 text-xs mt-1'>$err</p>" : '' ?>
                </div>
            <?php endforeach; ?>
            <div><label class="block text-sm text-mb-silver mb-2">Address</label>
                <textarea name="address" rows="2"
                    class="w-full bg-mb-black border border-mb-subtle/20 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-mb-accent transition-colors text-sm resize-none"><?= htmlspecialchars($c['address'] ?? '', ENT_QUOTES) ?></textarea>
            </div>
            <div><label class="block text-sm text-mb-silver mb-2">Notes</label>
                <textarea name="notes" rows="3"
                    class="w-full bg-mb-black border border-mb-subtle/20 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-mb-accent transition-colors text-sm resize-none"><?= htmlspecialchars($c['notes'] ?? '', ENT_QUOTES) ?></textarea>
            </div>
        </div>
        <div class="flex items-center justify-end gap-4">
            <a href="show.php?id=<?= $id ?>"
                class="text-mb-silver hover:text-white transition-colors text-sm">Cancel</a>
            <button type="submit"
                class="bg-mb-accent text-white px-8 py-3 rounded-full hover:bg-mb-accent/80 transition-colors font-medium">Save
                Changes</button>
        </div>
    </form>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>